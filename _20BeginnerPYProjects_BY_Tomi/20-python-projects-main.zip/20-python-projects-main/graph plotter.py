import matplotlib.pyplot as plt

x = [2, 4, 5]
y = [2, 3, 6]

plt.plot(x, y)


plt.xlabel('X Axis')

plt.ylabel( 'Y Axis')

plt.title('Demo Graph ')

plt.show()
